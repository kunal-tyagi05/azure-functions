# Azure Key Vault Secret Rotation

This project automates secret rotation using Terraform, Azure Functions, and Azure DevOps.